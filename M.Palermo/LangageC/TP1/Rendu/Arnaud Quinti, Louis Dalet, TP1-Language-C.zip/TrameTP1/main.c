#include <stdio.h>
#include "TP1.h"

int main()
{
    printf("TP Langage C\n");
    MenuTP1();
    return 0;
}
