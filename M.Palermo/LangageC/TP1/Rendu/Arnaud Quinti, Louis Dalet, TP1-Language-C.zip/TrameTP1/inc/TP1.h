#ifndef TP1_H_INCLUDED
#define TP1_H_INCLUDED


void TP1_1();
void TP1_2();
void TP1_3();
void TP1_4();
void TP1_5();



void MenuTP1();


#endif // TP1_H_INCLUDED
