#include <stdio.h>
#include "TP1.h"

void TP1_4() {

    printf("MenuTP1\n");
    float USD = 0.9512 , EUR = 1.0 , GBP = 1.1533 , CAD = 0.6958;
    int  VT3, VT4;
    char VT1, VT2;

    printf("Entrer une devise source :\n");
    scanf("%d",&VT1);

    printf("Entrer une devise cible :\n");
    scanf("%d",&VT2);

    printf("Entrer le nombre d'argent a convertir :\n");
    scanf("%d",&VT3);

    if ((VT1 == "USD" ) && (VT2 == "EUR")){
        
    }

}